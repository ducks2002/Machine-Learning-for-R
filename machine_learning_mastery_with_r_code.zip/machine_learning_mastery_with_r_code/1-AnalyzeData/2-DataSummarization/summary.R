# Summarize each attribute of a dataset using min, max, mean, 25%, 50% and 75%.


# load the iris dataset
data(iris)
# summarize the dataset
summary(iris)
